import logo from "./logo.svg";
import "./App.css";
import BaiTapThucHanhLayout from "./Components/BaiTapThucHanhLayout/BaiTapThucHanhLayout";


function App() {
  return (
    <div className="App">
      <BaiTapThucHanhLayout></BaiTapThucHanhLayout>

    </div>
  );
}
export default App;
 